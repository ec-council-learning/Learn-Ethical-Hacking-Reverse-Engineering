const fs = require('fs');
const pm = require('pixelmatch');
const PNG = require('pngjs').PNG;
const clipboardy = require('clipboardy');

//--- load keys ---
const keys=[];
for(var i=1; i<=12; i++){
  keys[i] = PNG.sync.read(fs.readFileSync('keys/k' + i + '.png'));
}

//--- read samples ---
const samples = [];
for(var j=1; j<=15; j++){
  samples[j] = PNG.sync.read(fs.readFileSync('samples/c' + j + '.png'));
}

var decodedStr='';

//-- compare with keys --
for(var j=1; j<=15; j++){
  const {width, height} = samples[j];
  for(var i=1; i<=12; i++){
    if(samples[j].width!==keys[i].width || samples[j].height!==keys[i].height){
      continue;
    }
    
    const numDiffPixels = pm(samples[j].data, keys[i].data, null, width, height, {threshold: 0.1});
    if(numDiffPixels===0) decodedStr += decode(i);
  }
}

function decode(i) {
  if(i===1) return ':D';
  else if(i===2) return ':)';
  else if(i===3) return ':p';
  else if(i===4) return ':(';
  else if(i===5) return ';)';
  else if(i===6) return 'B)';
  else if(i===7) return ':@';
  else if(i===8) return ':o';
  else if(i===9) return ':s';
  else if(i===10) return ':|';
  else if(i===11) return ':/';
  else if(i===12) return '<3';
}

clipboardy.writeSync(decodedStr);; //copy to clipboard
fs.writeFileSync('test.txt',decodedStr);